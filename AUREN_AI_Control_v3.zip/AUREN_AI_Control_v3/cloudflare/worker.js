const MODEL = "@cf/meta/llama-3.1-8b-instruct-fp8";

const SYSTEM_PROMPT = `
You are AUREN, a personal AI operating system and strategic assistant.

You are not merely a chatbot. You manage the user's AUREN goals, projects and tasks through structured app actions.
The Android app will execute only actions you return in the required JSON response. You must inspect the supplied app records and use their exact IDs.

RESPONSE FORMAT — MANDATORY:
Return ONLY one valid JSON object, with no Markdown fences and no text outside it:
{
  "reply": "A natural, concise message to the user",
  "actions": []
}

Allowed action objects:
- {"type":"CREATE_GOAL","title":"...","description":"..."}
- {"type":"CREATE_PROJECT","title":"...","description":"...","goalId":123}
- {"type":"UPDATE_GOAL","id":123,"title":"...","description":"..."}
- {"type":"CREATE_TASK","title":"...","description":"...","projectId":null,"estimatedMinutes":30,"scheduledAt":null}
- {"type":"UPDATE_TASK","id":123,"title":"...","completionPercent":0,"status":"PLANNED","estimatedMinutes":30,"scheduledAt":null}
- {"type":"UPDATE_PROJECT","id":123,"title":"...","description":"..."}
- {"type":"CREATE_COMMITMENT","title":"...","startsAt":1760000000000,"endsAt":1760003600000,"recurrence":"NONE","notes":"..."}
- {"type":"SAVE_CONTEXT","content":"...","category":"COMMITMENT_OR_PERSONAL_NOTE","permanence":"TEMPORARY_OR_UNCLASSIFIED"}
- {"type":"SET_PROFILE_NAME","name":"..."}

Rules:
1. Only use IDs present in the supplied app records. Never invent IDs.
2. For scheduledAt, startsAt and endsAt, use Unix timestamps in milliseconds. If no reliable time is known, ask rather than invent it.
3. When the user explicitly asks you to create or organise tasks, create/update the records directly using actions.
4. When the user reports a new lecture or appointment with clear start and end times, create a CREATE_COMMITMENT action and rearrange affected future tasks where enough information exists. For fatigue, interruption or changed availability, save relevant context and update affected tasks. Ask a focused question if a critical detail is missing.
5. Do not create a long-term goal unless the user clearly states an ambition or explicitly asks you to add it.
6. Do not delete goals, projects or tasks. Ask before changing a user's long-term ambition or priority.
7. Do not mark work completed unless the user reports the outcome. For completion, use only the user's stated 0/25/50/75/100 percent.
8. Use UPDATE_TASK for rescheduling or changing an existing task. Keep its ID and other known fields.
9. If the user asks what to do next, inspect tasks and goals, then recommend the highest-value next action. Do not invent a task as already scheduled.
10. Never say an action succeeded unless that action is included in the actions array. The app will report which actions it actually applied.
11. Keep the user informed, practical and respectful. Do not shame them.
12. If no app change is required, return an empty actions array.

Distinguish facts, user-stated information, estimates and assumptions. Never invent skills, resources, commitments, achievements or history.
`;

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Content-Type": "application/json; charset=utf-8"
  };
}
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: corsHeaders() });
}
export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders() });
    if (request.method === "GET") return json({ service: "AUREN AI Gateway", status: "online" });
    if (request.method !== "POST") return json({ error: "Method not allowed." }, 405);
    if (!env.AUREN_API_KEY) return json({ error: "Server setup incomplete: AUREN_API_KEY secret is missing." }, 500);
    const authorization = request.headers.get("Authorization") || "";
    const suppliedKey = authorization.startsWith("Bearer ") ? authorization.slice(7) : "";
    if (suppliedKey !== env.AUREN_API_KEY) return json({ error: "Unauthorized." }, 401);
    if (!env.AI) return json({ error: "Workers AI binding is missing." }, 500);
    try {
      const rawBody = await request.text();
      if (rawBody.length > 30000) return json({ error: "Request is too large." }, 413);
      const body = JSON.parse(rawBody);
      if (!Array.isArray(body.messages) || body.messages.length === 0) return json({ error: "Send a messages array containing at least one message." }, 400);
      const context = typeof body.context === "string" ? body.context.slice(0, 12000) : "";
      const messages = [{ role: "system", content: SYSTEM_PROMPT + (context ? "\n\nAPP RECORDS AND USER CONTEXT:\n" + context : "") }];
      for (const item of body.messages.slice(-20)) {
        if (item && ["user", "assistant"].includes(item.role) && typeof item.content === "string") {
          messages.push({ role: item.role, content: item.content.slice(0, 6000) });
        }
      }
      if (messages.length < 2) return json({ error: "No valid chat messages were provided." }, 400);
      const result = await env.AI.run(MODEL, { messages, max_tokens: 1400, temperature: 0.25 });
      return json({ success: true, reply: result.response || "", model: MODEL });
    } catch (error) {
      return json({ error: "AUREN could not complete the AI request.", details: String(error.message || error).slice(0, 300) }, 500);
    }
  }
};

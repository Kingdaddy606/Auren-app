# AUREN AI Control & Ranks — v1.2

Personal Android productivity system. Package: `com.auren.app`.

## Included in this release
- Cloudflare Workers AI chat connection with encrypted local credential storage.
- Structured AI control actions: create goals, projects and tasks; update task details, progress and schedules; update projects; save context; update profile name.
- App records are supplied to the AI with their real IDs. The app applies only supported actions and reports what it actually changed.
- Personal profile name saved locally and included in AI context.
- Pure-white interface with dark purple aura surfaces and purple accent system.
- Generated AUREN launcher icon and animated in-app launch splash.
- Overall Journey moved into The Architect screen.
- Rank ladder: Rose Badge, Growth Milestone, Comeback Award, Unstoppable. Rank promotion thresholds: 18/43/68/92. Demotion thresholds: 18/43/68/78, with current rank persisted locally.
- SMS remains reserved and disabled.

## Important current limitations
- The rank score is an initial rolling 14-day score based on assessed task completion percentages and penalties. It is not yet a fully audited scoring ledger.
- Overall Journey remains at 0% until meaningful milestone/evidence tracking is implemented. This avoids inventing progress from ordinary task check-offs.
- AI can create and update task schedule timestamps, but Android preparation alarms, exact start alarms, countdown timers and reboot recovery are not implemented in this build.
- Opportunity Radar, Life Simulator, Reality Gap and History are visual entry points, not fully connected engines in this release.
- The app is local-first. Do not uninstall an older build if you need its local data.
- The app has not been independently compiled in this environment; GitHub Actions performs the build.

## Cloudflare Worker update required for AI control
The app can only execute structured AI actions if the Worker uses the updated system prompt. Open your Cloudflare Worker `auren-ai-gateway`, replace its `worker.js` contents with `cloudflare/worker.js` from this ZIP, and Deploy. Keep the existing `AI` binding and `AUREN_API_KEY` secret. Do not put the server secret in the APK or GitHub repository.

## Build
- Java 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- compileSdk 35, minSdk 26
- Run `gradle --no-daemon assembleDebug` from this project root.

package com.auren.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import kotlinx.coroutines.delay
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.auren.app.data.*

private val Ink = Color(0xFF17211D)
private val Green = Color(0xFF6B4EFF)
private val Purple = Color(0xFF8C72FF)
private val Muted = Color(0xFF777783)
private val Canvas = Color(0xFFFFFFFF)
private val AuraBlack = Color(0xFF080812)

class MainActivity : ComponentActivity() {
    private val vm: AurenViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AurenTheme { AurenLaunchSplash { AurenApp(vm) } } }
    }
}

@Composable
private fun AurenTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, onPrimary = Color.White, background = Canvas, surface = Color.White, onSurface = Ink, secondary = Purple), content = content)
}

@Composable
private fun AurenLaunchSplash(content: @Composable () -> Unit) {
    var show by remember { mutableStateOf(true) }
    var start by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (start) 1f else 0.72f, animationSpec = tween(850), label = "logo-scale")
    val alpha by animateFloatAsState(if (start) 1f else 0.25f, animationSpec = tween(850), label = "logo-alpha")
    LaunchedEffect(Unit) { start = true; delay(1750); show = false }
    Box(Modifier.fillMaxSize()) {
        content()
        if (show) Box(Modifier.fillMaxSize().background(Color.White), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Image(painterResource(R.mipmap.ic_auren), contentDescription = "AUREN", modifier = Modifier.size(142.dp).graphicsLayer(scaleX = scale, scaleY = scale, alpha = alpha).padding(2.dp))
                Text("AUREN", color = Ink, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 3.dp))
                Text("PLAN  ·  FOCUS  ·  ACHIEVE", color = Purple, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(modifier = Modifier.width(92.dp).height(3.dp), color = Purple, trackColor = Color(0xFFEDEAFF))
            }
        }
    }
}

private enum class Tab(val label: String) { TODAY("Today"), GOALS("Goals"), PROJECTS("Projects"), AI("AI"), ARCHITECT("Architect") }

@Composable
private fun AurenApp(vm: AurenViewModel) {
    var selected by remember { mutableStateOf(Tab.TODAY) }
    var showSettings by remember { mutableStateOf(false) }
    val goals by vm.goals.collectAsStateWithLifecycle()
    val projects by vm.projects.collectAsStateWithLifecycle()
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val messages by vm.messages.collectAsStateWithLifecycle()
    val contextEntries by vm.contextEntries.collectAsStateWithLifecycle()
    val profileName by vm.profileName.collectAsStateWithLifecycle()
    Scaffold(
        containerColor = Canvas,
        topBar = {
            Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 20.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (profileName.isBlank()) "AUREN" else "Welcome, $profileName", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Your personal operating system", style = MaterialTheme.typography.labelSmall, color = Muted)
                }
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.AccountCircle, contentDescription = "Settings", tint = Ink) }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                Tab.entries.forEach { tab ->
                    val icon = when (tab) { Tab.TODAY -> Icons.Default.Home; Tab.GOALS -> Icons.Default.TrackChanges; Tab.PROJECTS -> Icons.Default.FolderOpen; Tab.AI -> Icons.Default.AutoAwesome; Tab.ARCHITECT -> Icons.Default.Explore }
                    NavigationBarItem(selected = selected == tab, onClick = { selected = tab }, icon = { Icon(icon, contentDescription = tab.label) }, label = { Text(tab.label, style = MaterialTheme.typography.labelSmall) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, selectedTextColor = Green, indicatorColor = Color(0xFFF0EDFF)))
                }
            }
        }
    ) { padding ->
        when (selected) {
            Tab.TODAY -> TodayScreen(Modifier.padding(padding), goals.size, projects.size, tasks, profileName, onOpenAI = { selected = Tab.AI })
            Tab.GOALS -> GoalsScreen(Modifier.padding(padding), goals, vm)
            Tab.PROJECTS -> ProjectsScreen(Modifier.padding(padding), projects, vm)
            Tab.AI -> AiScreen(Modifier.padding(padding), messages, contextEntries.size, vm)
            Tab.ARCHITECT -> ArchitectScreen(Modifier.padding(padding), goals, projects, tasks, vm)
        }
    }
    if (showSettings) SettingsDialog(
        initialEndpoint = vm.gatewayEndpoint(),
        initialName = profileName,
        onSaveName = { vm.saveProfileName(it) },
        onSaveGateway = { endpoint, token -> vm.saveGatewaySettings(endpoint, token) },
        onDismiss = { showSettings = false }
    )
}

@Composable
private fun TodayScreen(modifier: Modifier, goalCount: Int, projectCount: Int, tasks: List<TaskEntity>, profileName: String, onOpenAI: () -> Unit) {
    val done = tasks.count { it.completionPercent == 100 }
    val daily = if (tasks.isEmpty()) 0 else (tasks.sumOf { it.completionPercent } / tasks.size)
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        item {
            Text(if (profileName.isBlank()) "Your day, directed by AI." else "Your day, $profileName.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
            Text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), color = Muted, style = MaterialTheme.typography.bodyMedium)
        }
        item { ProgressCard("TODAY'S PERFORMANCE", "$daily%", daily / 100f, "$done of ${tasks.size} activities fully completed", null, false) }
        item {
            SectionTitle("NEXT ACTION", "Managed by AUREN")
            Surface(shape = RoundedCornerShape(22.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Green)
                    Text("Your AI operating partner", fontWeight = FontWeight.SemiBold, color = Ink)
                    Text("AUREN can now create and update goals, projects and tasks when it returns valid control actions. Scheduling automation and alarms will continue to expand in later releases.", color = Muted, style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = onOpenAI) { Text("Talk to AUREN") }
                }
            }
        }
        item {
            SectionTitle("YOUR SYSTEM", "Live local records")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniStat("Goals", goalCount.toString(), Modifier.weight(1f))
                MiniStat("Projects", projectCount.toString(), Modifier.weight(1f))
                MiniStat("Activities", tasks.size.toString(), Modifier.weight(1f))
            }
        }
        if (tasks.isNotEmpty()) {
            item { SectionTitle("YOUR AI PLAN", "${tasks.size} saved tasks") }
            items(tasks.take(8), key = { it.id }) { task ->
                Surface(color = Color.White, shape = RoundedCornerShape(17.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (task.completionPercent == 100) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, contentDescription = null, tint = Purple)
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text(task.title, color = Ink, fontWeight = FontWeight.SemiBold)
                            Text("${task.status.replace('_',' ')} · ${task.estimatedMinutes} min · ${task.completionPercent}%", color = Muted, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
        item {
            Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFF4F1FF)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lightbulb, contentDescription = null, tint = Green)
                    Spacer(Modifier.width(10.dp))
                    Text("Tell AUREN about classes, appointments or a difficult day. It can use your saved context and make supported changes to your plans.", color = Ink, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun ProgressCard(title: String, value: String, progress: Float, subtitle: String, change: String?, showChange: Boolean) {
    Surface(shape = RoundedCornerShape(22.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = Muted, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Ink)
                if (showChange && change != null) { Spacer(Modifier.width(8.dp)); Text(change, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Green); Text("  rate change", color = Muted, style = MaterialTheme.typography.labelSmall) }
            }
            LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(9.dp), color = Green, trackColor = Color(0xFFE9EEEA))
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Muted)
            if (showChange) Text("Weekly rate comparison will appear after sufficient performance history.", style = MaterialTheme.typography.labelSmall, color = Muted)
        }
    }
}

@Composable
private fun GoalsScreen(modifier: Modifier, goals: List<GoalEntity>, vm: AurenViewModel) {
    var showAdd by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(18.dp)) {
        HeaderWithAction("Your ambitions", "Goals are the outcomes AUREN plans towards.", "Add") { showAdd = true }
        Spacer(Modifier.height(14.dp))
        if (goals.isEmpty()) EmptyState("No ambitions added yet", "Start by telling AUREN what you want to achieve. The AI planning conversation will help turn it into a structured journey.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(goals, key = { it.id }) { goal -> Surface(color = Color.White, shape = RoundedCornerShape(18.dp)) { Column(Modifier.fillMaxWidth().padding(16.dp)) { Text(goal.title, fontWeight = FontWeight.SemiBold); if (goal.description.isNotBlank()) Text(goal.description, color = Muted, style = MaterialTheme.typography.bodySmall); Text("Awaiting AI milestone planning", color = Green, style = MaterialTheme.typography.labelSmall) } } } }
    }
    if (showAdd) AddItemDialog("Add an ambition", "What do you ultimately want to achieve?", onDismiss = { showAdd = false }) { title, desc -> vm.addGoal(title, desc); showAdd = false }
}

@Composable
private fun ProjectsScreen(modifier: Modifier, projects: List<ProjectEntity>, vm: AurenViewModel) {
    var showAdd by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(18.dp)) {
        HeaderWithAction("Projects", "AUREN organises projects to move your ambitions forward.", "Add") { showAdd = true }
        Spacer(Modifier.height(14.dp))
        if (projects.isEmpty()) EmptyState("No projects yet", "Projects will be generated and linked to your ambitions by AUREN's planning engine.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(projects, key = { it.id }) { project -> Surface(color = Color.White, shape = RoundedCornerShape(18.dp)) { Column(Modifier.fillMaxWidth().padding(16.dp)) { Text(project.title, fontWeight = FontWeight.SemiBold); if (project.description.isNotBlank()) Text(project.description, color = Muted, style = MaterialTheme.typography.bodySmall); Text("Not yet scheduled", color = Green, style = MaterialTheme.typography.labelSmall) } } } }
    }
    if (showAdd) AddItemDialog("Add a project", "Describe a project", onDismiss = { showAdd = false }) { title, desc -> vm.addProject(title, desc); showAdd = false }
}

@Composable
private fun AiScreen(modifier: Modifier, messages: List<MessageEntity>, contextCount: Int, vm: AurenViewModel) {
    var draft by remember { mutableStateOf("") }
    val status by vm.aiStatus.collectAsStateWithLifecycle()
    val sending by vm.sending.collectAsStateWithLifecycle()
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text("AI Assistant", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Your ongoing conversation with AUREN", color = Muted, style = MaterialTheme.typography.bodySmall)
        Surface(color = Color(0xFFEAF4EE), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 10.dp)) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(if (sending) "AUREN IS THINKING" else "AI CONNECTION", fontWeight = FontWeight.SemiBold, color = Ink, style = MaterialTheme.typography.bodySmall)
                Text(status, color = Muted, style = MaterialTheme.typography.labelSmall)
                Text("$contextCount saved context records on this device", color = Green, style = MaterialTheme.typography.labelSmall)
            }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            if (messages.isEmpty()) item { EmptyState("Start by telling AUREN about your life", "For example: I have lectures tomorrow from 10 AM to 2 PM, and I need time to travel afterwards.") }
            items(messages, key = { it.id }) { message ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.role == "USER") Arrangement.End else Arrangement.Start) {
                    Surface(color = if (message.role == "USER") Color(0xFFEAF4EE) else Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                        Column(Modifier.padding(13.dp)) {
                            Text(if (message.role == "USER") "YOU" else "AUREN", style = MaterialTheme.typography.labelSmall, color = Green, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(3.dp))
                            Text(message.content, color = Ink, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f), placeholder = { Text("Tell AUREN what's happening…") }, shape = RoundedCornerShape(24.dp), maxLines = 4)
            IconButton(onClick = { vm.sendMessage(draft); draft = "" }, modifier = Modifier.size(48.dp).background(Green, CircleShape), enabled = draft.isNotBlank() && !sending) {
                if (sending) CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                else Icon(Icons.Default.ArrowUpward, contentDescription = "Send message", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ArchitectScreen(modifier: Modifier, goals: List<GoalEntity>, projects: List<ProjectEntity>, tasks: List<TaskEntity>, vm: AurenViewModel) {
    val items = listOf(Triple("Life Simulator", "Compare possible futures, assumptions and trade-offs.", Icons.Default.Timeline), Triple("Opportunity Radar", "Search for real opportunities that fit your circumstances.", Icons.Default.Radar), Triple("Reality Gap", "Identify what is missing between today and your goal.", Icons.Default.Difference), Triple("History", "Review decisions, outcomes, achievements and lessons.", Icons.Default.History))
    val now = System.currentTimeMillis()
    val recent = tasks.filter { it.createdAt >= now - 14L * 24 * 60 * 60 * 1000 }
    val assessed = recent.filter { task ->
        task.status in listOf("COMPLETED", "AWAITING_REVIEW", "IN_PROGRESS", "POSTPONED", "CANCELLED") ||
            (task.scheduledAt != null && task.scheduledAt <= now)
    }
    val score = if (assessed.isEmpty()) 0 else {
        val raw = assessed.sumOf { it.completionPercent }.toDouble()
        val penalties = assessed.sumOf { task ->
            when {
                task.status == "POSTPONED" || task.status == "CANCELLED" -> 1
                task.completionPercent == 0 && task.scheduledAt != null && task.scheduledAt <= now -> 10
                else -> 0
            }
        }
        ((raw - penalties) / assessed.size).toInt().coerceIn(0, 100)
    }
    var rankState by remember { mutableStateOf(vm.evaluateRank(score)) }
    LaunchedEffect(score) { rankState = vm.evaluateRank(score) }
    val rankLevel = rankState.first
    val rank = rankState.second
    val next = when (rankLevel) { 0 -> 18; 1 -> 43; 2 -> 68; 3 -> 92; else -> 100 }
    val journeyLabel = if (goals.isEmpty()) "0%" else "Pending"
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("The Architect", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Your strategic intelligence centre · overall journey lives here", color = Muted)
        }
        item {
            Surface(shape = RoundedCornerShape(26.dp), color = AuraBlack, modifier = Modifier.fillMaxWidth()) {
                Box(Modifier.background(Brush.linearGradient(listOf(Color(0xFF090912), Color(0xFF211449), Color(0xFF090912)))).padding(19.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFB9A7FF)); Spacer(Modifier.width(8.dp)); Text("YOUR OVERALL JOURNEY", color = Color(0xFFD8D0FF), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium) }
                        Text(journeyLabel, color = Color.White, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.ExtraBold)
                        LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Color(0xFF9D7BFF), trackColor = Color(0xFF39304F))
                        Text(if (goals.isEmpty()) "Add your ambitions to begin measuring meaningful milestones." else "Milestone-based journey measurement is being prepared. Ordinary task check-offs will not inflate your long-term progress.", color = Color(0xFFC9C3D9), style = MaterialTheme.typography.bodySmall)
                        Text("${goals.size} ambitions  ·  ${projects.size} projects  ·  ${tasks.size} tasks", color = Color(0xFFB9A7FF), style = MaterialTheme.typography.labelSmall)
                        Text("Weekly progress-rate indicator appears when enough comparable history exists.", color = Color(0xFF9C95B0), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        item {
            Surface(shape = RoundedCornerShape(24.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.EmojiEvents, tint = Purple, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("YOUR CURRENT RANK", fontWeight = FontWeight.Bold, color = Ink, style = MaterialTheme.typography.labelMedium) }
                    Text(rank, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = Ink)
                    Text(if (assessed.isEmpty()) "Complete and review scheduled tasks to establish your first 14-day rank." else "$score% recent performance · ${assessed.size} assessed activities · rolling 14-day window", color = Muted, style = MaterialTheme.typography.bodySmall)
                    LinearProgressIndicator(progress = { (score / 100f).coerceIn(0f,1f) }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Purple, trackColor = Color(0xFFF0EDFF))
                    Text(if (rankLevel == 4) "Top rank reached" else "Next rank threshold: $next%", color = Purple, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                    Text("Rank ladder: Rose Badge (18) → Growth Milestone (43) → Comeback Award (68) → Unstoppable (92). Demotion is gradual: the top tier can fall at 78, then lower tiers at 68, 43 and 18. Ordinary missed work costs 10 marks; a legitimate cancellation or reschedule costs about 1.", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Text("STRATEGIC TOOLS", color = Muted, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium) }
        items(items) { item -> Surface(color = Color.White, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) { Surface(color = Color(0xFFF0EDFF), shape = RoundedCornerShape(14.dp)) { Icon(item.third, contentDescription = null, tint = Purple, modifier = Modifier.padding(10.dp).size(26.dp)) }; Spacer(Modifier.width(14.dp)); Column { Text(item.first, fontWeight = FontWeight.SemiBold); Text(item.second, color = Muted, style = MaterialTheme.typography.bodySmall); Text("Strategic workspace", color = Purple, style = MaterialTheme.typography.labelSmall) } } } }
    }
}

@Composable
private fun SettingsDialog(initialEndpoint: String, initialName: String, onSaveName: (String) -> Unit, onSaveGateway: (String, String) -> Unit, onDismiss: () -> Unit) {
    var endpoint by remember { mutableStateOf(initialEndpoint) }
    var profileName by remember { mutableStateOf(initialName) }
    var token by remember { mutableStateOf("") }
    var showToken by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Settings") }, text = {
        Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("YOUR PROFILE", fontWeight = FontWeight.Bold, color = Green, style = MaterialTheme.typography.labelMedium)
            OutlinedTextField(value = profileName, onValueChange = { profileName = it }, label = { Text("Your name") }, placeholder = { Text("What should AUREN call you?") }, singleLine = true)
            Text("AUREN uses your name in greetings, encouragement and relevant AI context.", color = Muted, style = MaterialTheme.typography.bodySmall)
            Divider()
            Text("AUREN AI CONNECTION", fontWeight = FontWeight.Bold, color = Green, style = MaterialTheme.typography.labelMedium)
            Text("Connect your personal Cloudflare Worker. Your access secret is encrypted using Android Keystore on this device.", color = Muted, style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(value = endpoint, onValueChange = { endpoint = it }, label = { Text("Gateway URL") }, singleLine = true)
            OutlinedTextField(value = token, onValueChange = { token = it }, label = { Text("AUREN access secret") }, placeholder = { Text("Paste your AUREN_API_KEY value") }, singleLine = true, visualTransformation = if (showToken) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showToken = !showToken }) { Text(if (showToken) "Hide" else "Show") } })
            Text("Save a new secret here. It is not included in the APK source code.", color = Muted, style = MaterialTheme.typography.labelSmall)
            Divider()
            Text("PRIVACY & OTHER SETTINGS", fontWeight = FontWeight.Bold, color = Ink, style = MaterialTheme.typography.labelMedium)
            Text("Personal profile and AI memory")
            Text("Notifications and alarms")
            Text("Privacy and history controls")
            Divider()
            Text("SMS TASK MESSENGER", fontWeight = FontWeight.Bold, color = Ink)
            Text("Reserved interface only. SMS sending, number verification and message queues remain disabled.", color = Muted, style = MaterialTheme.typography.bodySmall)
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Master switch", modifier = Modifier.weight(1f)); Switch(checked = false, onCheckedChange = {}, enabled = false) }
            Text("Not activated", color = Muted, style = MaterialTheme.typography.labelSmall)
        }
    }, confirmButton = {
        TextButton(onClick = { onSaveName(profileName); if (token.isNotBlank()) onSaveGateway(endpoint, token); onDismiss() }, enabled = true) { Text("Save settings") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } })
}

@Composable
private fun HeaderWithAction(title: String, subtitle: String, action: String, onAction: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall) }; TextButton(onClick = onAction) { Icon(Icons.Default.Add, null); Text(action) } }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Ink); Spacer(Modifier.weight(1f)); Text(subtitle, style = MaterialTheme.typography.labelSmall, color = Muted) } }

@Composable
private fun MiniStat(label: String, value: String, modifier: Modifier) { Surface(modifier, color = Color.White, shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(13.dp)) { Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text(label, color = Muted, style = MaterialTheme.typography.labelSmall) } } }

@Composable
private fun EmptyState(title: String, body: String) { Surface(color = Color.White, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Green); Text(title, fontWeight = FontWeight.SemiBold); Text(body, color = Muted, style = MaterialTheme.typography.bodySmall) } } }

@Composable
private fun AddItemDialog(title: String, hint: String, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var description by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(name, { name = it }, label = { Text(hint) }, singleLine = true); OutlinedTextField(description, { description = it }, label = { Text("Additional context (optional)") }) } }, confirmButton = { TextButton(onClick = { onSave(name, description) }, enabled = name.isNotBlank()) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

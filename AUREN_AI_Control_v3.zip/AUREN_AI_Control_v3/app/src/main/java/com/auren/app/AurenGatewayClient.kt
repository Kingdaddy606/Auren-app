package com.auren.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AurenGatewayClient {
    fun send(endpoint: String, token: String, messages: List<Pair<String, String>>, context: String): String {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Authorization", "Bearer $token")
        }
        try {
            val body = JSONObject().apply {
                put("messages", JSONArray().apply {
                    messages.forEach { (role, content) ->
                        put(JSONObject().put("role", role).put("content", content))
                    }
                })
                put("context", context)
            }.toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val response = try { JSONObject(responseText) } catch (_: Exception) { JSONObject() }
            if (code !in 200..299 || !response.optBoolean("success", false)) {
                val message = response.optString("error").ifBlank { "HTTP $code: $responseText" }
                throw IllegalStateException(message)
            }
            return response.optString("reply").ifBlank { "AUREN received the message but returned an empty reply." }
        } finally {
            connection.disconnect()
        }
    }
}

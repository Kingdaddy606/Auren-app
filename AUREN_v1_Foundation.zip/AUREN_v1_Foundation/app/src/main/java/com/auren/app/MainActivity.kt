package com.auren.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.auren.app.data.*
import kotlinx.coroutines.launch

private val Ink = Color(0xFF20231F)
private val Muted = Color(0xFF777B73)
private val Paper = Color(0xFFF7F7F4)
private val Green = Color(0xFF687B61)
private val Line = Color(0xFFE6E7E1)

class MainActivity : ComponentActivity() {
    private val dao by lazy { AurenDatabase.get(this).dao() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AurenApp(dao) }
    }
}

@Composable
fun AurenApp(dao: AurenDao) {
    var tab by remember { mutableStateOf("Today") }
    val goals by dao.goals().collectAsStateWithLifecycle(emptyList())
    val projects by dao.projects().collectAsStateWithLifecycle(emptyList())
    val tasks by dao.tasks().collectAsStateWithLifecycle(emptyList())
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Paper, surface = Color.White, onBackground = Ink, onSurface = Ink)) {
        Scaffold(containerColor = Paper, bottomBar = {
            NavigationBar(containerColor = Color.White, contentColor = Ink) {
                listOf("Today" to Icons.Default.Today, "Goals" to Icons.Default.Flag, "Projects" to Icons.Default.FolderOpen, "Tasks" to Icons.Default.CheckCircle, "History" to Icons.Default.History).forEach { (name, icon) ->
                    NavigationBarItem(selected = tab == name, onClick = { tab = name }, icon = { Icon(icon, null) }, label = { Text(name, fontSize = 10.sp) })
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("AUREN", fontSize = 25.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp, color = Ink)
                        Text("YOUR PERSONAL OPERATING SYSTEM", fontSize = 9.sp, letterSpacing = 1.4.sp, color = Muted)
                    }
                    Box(Modifier.size(40.dp).background(Color.White, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Green) }
                }
                when (tab) {
                    "Today" -> TodayScreen(goals.size, projects.size, tasks, onTasks = { tab = "Tasks" })
                    "Goals" -> CollectionScreen("Your goals", "Define the outcomes you want to achieve.", goals.map { it.title }, "Add a goal", { title -> dao.addGoal(Goal(title = title)) }, { index -> goals.getOrNull(index)?.let { dao.deleteGoal(it) } })
                    "Projects" -> CollectionScreen("Your projects", "Turn ambitions into organized work.", projects.map { it.title }, "Add a project", { title -> dao.addProject(Project(title = title)) }, { index -> projects.getOrNull(index)?.let { dao.deleteProject(it) } })
                    "Tasks" -> TaskScreen(tasks, { title -> dao.addTask(TaskItem(title = title)) }, { item -> dao.updateTask(item.copy(isDone = !item.isDone)) }, { item -> dao.deleteTask(item) })
                    else -> HistoryScreen(tasks.count { it.isDone }, tasks.size)
                }
            }
        }
    }
}

@Composable fun TodayScreen(goalCount: Int, projectCount: Int, tasks: List<TaskItem>, onTasks: () -> Unit) {
    val done = tasks.count { it.isDone }; val total = tasks.size
    Text("YOUR DAY", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.SemiBold)
    Text("Make today\ncount.", fontSize = 36.sp, lineHeight = 40.sp, fontWeight = FontWeight.SemiBold, color = Ink, modifier = Modifier.padding(top = 8.dp, bottom = 18.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Ink), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text("DAILY OVERVIEW", color = Color(0xFFBFC5B9), fontSize = 10.sp, letterSpacing = 1.5.sp)
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Metric("TASKS", "$done / $total", Color.White)
                Metric("GOALS", goalCount.toString(), Color.White)
                Metric("PROJECTS", projectCount.toString(), Color.White)
            }
            LinearProgressIndicator(progress = { if (total == 0) 0f else done.toFloat() / total }, modifier = Modifier.fillMaxWidth().padding(top = 18.dp).height(5.dp), color = Color(0xFFB5C9A8), trackColor = Color(0xFF454B43))
            Text(if (total == 0) "Your plan starts with one task." else "$done of $total tasks completed", color = Color(0xFFBFC5B9), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
    Text("FOCUS", color = Muted, fontSize = 11.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 25.dp, bottom = 10.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().clickable { onTasks() }) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFFEAF0E6), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.AddTask, null, tint = Green) }
            Column(Modifier.weight(1f).padding(start = 12.dp)) { Text("Build your next action", fontWeight = FontWeight.SemiBold); Text("Add a task and give it a place in your day.", color = Muted, fontSize = 12.sp) }
            Icon(Icons.Default.ArrowForward, null, tint = Muted)
        }
    }
    Text("AUREN is ready when you are.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 22.dp))
}

@Composable fun Metric(label: String, value: String, color: Color) { Column { Text(label, color = Color(0xFFBFC5B9), fontSize = 9.sp, letterSpacing = 1.sp); Text(value, color = color, fontSize = 23.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 3.dp)) } }

@Composable fun CollectionScreen(title: String, subtitle: String, entries: List<String>, addLabel: String, add: (String) -> Unit, delete: (Int) -> Unit) {
    var show by remember { mutableStateOf(false) }; var value by remember { mutableStateOf("") }
    Text(title, fontSize = 29.sp, fontWeight = FontWeight.SemiBold, color = Ink)
    Text(subtitle, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))
    Button(onClick = { show = true }, shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = Green), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text(addLabel) }
    if (entries.isEmpty()) EmptyState("Nothing here yet", "Use the button above to create your first entry.")
    LazyColumn(contentPadding = PaddingValues(top = 14.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        items(entries.indices.toList()) { i -> EntryCard(entries[i], onDelete = { delete(i) }) }
    }
    if (show) AlertDialog(onDismissRequest = { show = false }, title = { Text(addLabel) }, text = { OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text("Name") }, singleLine = true) }, confirmButton = { TextButton(onClick = { if (value.isNotBlank()) add(value.trim()); value = ""; show = false }) { Text("Save") } }, dismissButton = { TextButton(onClick = { show = false }) { Text("Cancel") } })
}

@Composable fun TaskScreen(tasks: List<TaskItem>, add: (String) -> Unit, toggle: (TaskItem) -> Unit, delete: (TaskItem) -> Unit) {
    var show by remember { mutableStateOf(false) }; var value by remember { mutableStateOf("") }
    Text("Your tasks", fontSize = 29.sp, fontWeight = FontWeight.SemiBold)
    Text("Small actions. Meaningful progress.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))
    Button(onClick = { show = true }, shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = Green), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Add a task") }
    if (tasks.isEmpty()) EmptyState("Your task list is clear", "Add the next useful action you want to take.")
    LazyColumn(contentPadding = PaddingValues(top = 14.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        items(tasks, key = { it.id }) { item ->
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = item.isDone, onCheckedChange = { toggle(item) }, colors = CheckboxDefaults.colors(checkedColor = Green))
                    Text(item.title, modifier = Modifier.weight(1f).padding(start = 8.dp), color = if (item.isDone) Muted else Ink, fontWeight = FontWeight.Medium)
                    IconButton(onClick = { delete(item) }) { Icon(Icons.Default.DeleteOutline, "Delete", tint = Muted) }
                }
            }
        }
    }
    if (show) AlertDialog(onDismissRequest = { show = false }, title = { Text("Add a task") }, text = { OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text("What needs to be done?") }) }, confirmButton = { TextButton(onClick = { if (value.isNotBlank()) add(value.trim()); value = ""; show = false }) { Text("Save") } }, dismissButton = { TextButton(onClick = { show = false }) { Text("Cancel") } })
}

@Composable fun EntryCard(title: String, onDelete: () -> Unit) { Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), fontWeight = FontWeight.Medium); IconButton(onClick = onDelete) { Icon(Icons.Default.DeleteOutline, "Delete", tint = Muted) } } } }
@Composable fun EmptyState(title: String, body: String) { Column(Modifier.fillMaxWidth().padding(top = 30.dp, bottom = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Inbox, null, tint = Color(0xFFADB2A8), modifier = Modifier.size(34.dp)); Text(title, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 9.dp)); Text(body, color = Muted, fontSize = 12.sp) } }
@Composable fun HistoryScreen(done: Int, total: Int) { Text("Your history", fontSize = 29.sp, fontWeight = FontWeight.SemiBold); Text("A record of the work you put in.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp)); Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) { Text("TASK ACTIVITY", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp); Text("$done completed", fontSize = 27.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp)); Text("$total total tasks recorded", color = Muted, fontSize = 12.sp) } }; Text("Detailed weekly reviews will arrive in a later phase.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 16.dp)) }

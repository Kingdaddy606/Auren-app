package com.auren.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.auren.app.data.*

private val Ink = Color(0xFF17211D)
private val Green = Color(0xFF16845B)
private val Muted = Color(0xFF78847E)
private val Canvas = Color(0xFFF7F9F7)

class MainActivity : ComponentActivity() {
    private val vm: AurenViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AurenTheme { AurenApp(vm) } }
    }
}

@Composable
private fun AurenTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, onPrimary = Color.White, background = Canvas, surface = Color.White, onSurface = Ink, secondary = Green), content = content)
}

private enum class Tab(val label: String) { TODAY("Today"), GOALS("Goals"), PROJECTS("Projects"), AI("AI"), ARCHITECT("Architect") }

@Composable
private fun AurenApp(vm: AurenViewModel) {
    var selected by remember { mutableStateOf(Tab.TODAY) }
    var showSettings by remember { mutableStateOf(false) }
    val goals by vm.goals.collectAsStateWithLifecycle()
    val projects by vm.projects.collectAsStateWithLifecycle()
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    val messages by vm.messages.collectAsStateWithLifecycle()
    val contextEntries by vm.contextEntries.collectAsStateWithLifecycle()
    Scaffold(
        containerColor = Canvas,
        topBar = {
            Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 20.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("AUREN", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Your personal operating system", style = MaterialTheme.typography.labelSmall, color = Muted)
                }
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.AccountCircle, contentDescription = "Settings", tint = Ink) }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                Tab.entries.forEach { tab ->
                    val icon = when (tab) { Tab.TODAY -> Icons.Default.Home; Tab.GOALS -> Icons.Default.TrackChanges; Tab.PROJECTS -> Icons.Default.FolderOpen; Tab.AI -> Icons.Default.AutoAwesome; Tab.ARCHITECT -> Icons.Default.Explore }
                    NavigationBarItem(selected = selected == tab, onClick = { selected = tab }, icon = { Icon(icon, contentDescription = tab.label) }, label = { Text(tab.label, style = MaterialTheme.typography.labelSmall) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, selectedTextColor = Green, indicatorColor = Color(0xFFE6F3EC)))
                }
            }
        }
    ) { padding ->
        when (selected) {
            Tab.TODAY -> TodayScreen(Modifier.padding(padding), goals.size, projects.size, tasks, onOpenAI = { selected = Tab.AI })
            Tab.GOALS -> GoalsScreen(Modifier.padding(padding), goals, vm)
            Tab.PROJECTS -> ProjectsScreen(Modifier.padding(padding), projects, vm)
            Tab.AI -> AiScreen(Modifier.padding(padding), messages, contextEntries.size, vm)
            Tab.ARCHITECT -> ArchitectScreen(Modifier.padding(padding))
        }
    }
    if (showSettings) SettingsDialog(onDismiss = { showSettings = false })
}

@Composable
private fun TodayScreen(modifier: Modifier, goalCount: Int, projectCount: Int, tasks: List<TaskEntity>, onOpenAI: () -> Unit) {
    val done = tasks.count { it.completionPercent == 100 }
    val daily = if (tasks.isEmpty()) 0 else (tasks.sumOf { it.completionPercent } / tasks.size)
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        item {
            Text("Your day, directed by AI.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
            Text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), color = Muted, style = MaterialTheme.typography.bodyMedium)
        }
        item { ProgressCard("YOUR OVERALL JOURNEY", "0%", 0f, "Cumulative progress across your ambitions", null, true) }
        item { ProgressCard("TODAY'S PERFORMANCE", "$daily%", daily / 100f, "$done of ${tasks.size} activities fully completed", null, false) }
        item {
            SectionTitle("NEXT ACTION", "Managed by AUREN")
            Surface(shape = RoundedCornerShape(22.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Green)
                    Text("Your AI planning engine is being connected", fontWeight = FontWeight.SemiBold, color = Ink)
                    Text("Once connected, AUREN will create and schedule your next actions from your ambitions and commitments. You won't need to manage a task list.", color = Muted, style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = onOpenAI) { Text("Talk to AUREN") }
                }
            }
        }
        item {
            SectionTitle("YOUR SYSTEM", "Live local records")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniStat("Goals", goalCount.toString(), Modifier.weight(1f))
                MiniStat("Projects", projectCount.toString(), Modifier.weight(1f))
                MiniStat("Activities", tasks.size.toString(), Modifier.weight(1f))
            }
        }
        item {
            Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFEAF4EE)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lightbulb, contentDescription = null, tint = Green)
                    Spacer(Modifier.width(10.dp))
                    Text("Tell AUREN about classes, appointments or a difficult day. Its planning engine will use that context when connected.", color = Ink, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun ProgressCard(title: String, value: String, progress: Float, subtitle: String, change: String?, showChange: Boolean) {
    Surface(shape = RoundedCornerShape(22.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = Muted, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Ink)
                if (showChange && change != null) { Spacer(Modifier.width(8.dp)); Text(change, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Green); Text("  rate change", color = Muted, style = MaterialTheme.typography.labelSmall) }
            }
            LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(9.dp), color = Green, trackColor = Color(0xFFE9EEEA))
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Muted)
            if (showChange) Text("Weekly rate comparison will appear after sufficient performance history.", style = MaterialTheme.typography.labelSmall, color = Muted)
        }
    }
}

@Composable
private fun GoalsScreen(modifier: Modifier, goals: List<GoalEntity>, vm: AurenViewModel) {
    var showAdd by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(18.dp)) {
        HeaderWithAction("Your ambitions", "Goals are the outcomes AUREN plans towards.", "Add") { showAdd = true }
        Spacer(Modifier.height(14.dp))
        if (goals.isEmpty()) EmptyState("No ambitions added yet", "Start by telling AUREN what you want to achieve. The AI planning conversation will help turn it into a structured journey.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(goals, key = { it.id }) { goal -> Surface(color = Color.White, shape = RoundedCornerShape(18.dp)) { Column(Modifier.fillMaxWidth().padding(16.dp)) { Text(goal.title, fontWeight = FontWeight.SemiBold); if (goal.description.isNotBlank()) Text(goal.description, color = Muted, style = MaterialTheme.typography.bodySmall); Text("Awaiting AI milestone planning", color = Green, style = MaterialTheme.typography.labelSmall) } } } }
    }
    if (showAdd) AddItemDialog("Add an ambition", "What do you ultimately want to achieve?", onDismiss = { showAdd = false }) { title, desc -> vm.addGoal(title, desc); showAdd = false }
}

@Composable
private fun ProjectsScreen(modifier: Modifier, projects: List<ProjectEntity>, vm: AurenViewModel) {
    var showAdd by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(18.dp)) {
        HeaderWithAction("Projects", "AUREN organises projects to move your ambitions forward.", "Add") { showAdd = true }
        Spacer(Modifier.height(14.dp))
        if (projects.isEmpty()) EmptyState("No projects yet", "Projects will be generated and linked to your ambitions by AUREN's planning engine.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(projects, key = { it.id }) { project -> Surface(color = Color.White, shape = RoundedCornerShape(18.dp)) { Column(Modifier.fillMaxWidth().padding(16.dp)) { Text(project.title, fontWeight = FontWeight.SemiBold); if (project.description.isNotBlank()) Text(project.description, color = Muted, style = MaterialTheme.typography.bodySmall); Text("Not yet scheduled", color = Green, style = MaterialTheme.typography.labelSmall) } } } }
    }
    if (showAdd) AddItemDialog("Add a project", "Describe a project", onDismiss = { showAdd = false }) { title, desc -> vm.addProject(title, desc); showAdd = false }
}

@Composable
private fun AiScreen(modifier: Modifier, messages: List<MessageEntity>, contextCount: Int, vm: AurenViewModel) {
    var draft by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text("AI Assistant", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Your ongoing conversation with AUREN", color = Muted, style = MaterialTheme.typography.bodySmall)
        Surface(color = Color(0xFFEAF4EE), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 10.dp)) {
            Column(Modifier.padding(12.dp)) {
                Text("AI connection not yet active", fontWeight = FontWeight.SemiBold, color = Ink, style = MaterialTheme.typography.bodySmall)
                Text("Messages are saved locally as context notes. A connected AI service is required before AUREN can understand them, reply intelligently or rearrange your schedule.", color = Muted, style = MaterialTheme.typography.labelSmall)
                Text("$contextCount context records saved on this device", color = Green, style = MaterialTheme.typography.labelSmall)
            }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            if (messages.isEmpty()) item { EmptyState("Start by telling AUREN about your life", "For example: I have lectures tomorrow from 10 AM to 2 PM, and I need time to travel afterwards.") }
            items(messages, key = { it.id }) { message ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.role == "USER") Arrangement.End else Arrangement.Start) {
                    Surface(color = if (message.role == "USER") Color(0xFFEAF4EE) else Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 310.dp)) { Text(message.content, Modifier.padding(13.dp), color = Ink, style = MaterialTheme.typography.bodyMedium) }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f), placeholder = { Text("Tell AUREN what's happening...") }, shape = RoundedCornerShape(24.dp), maxLines = 4)
            IconButton(onClick = { vm.saveMessage(draft); draft = "" }, modifier = Modifier.size(48.dp).background(Green, CircleShape), enabled = draft.isNotBlank()) { Icon(Icons.Default.ArrowUpward, contentDescription = "Save message", tint = Color.White) }
        }
    }
}

@Composable
private fun ArchitectScreen(modifier: Modifier) {
    val items = listOf(Triple("Life Simulator", "Compare possible futures, assumptions and trade-offs.", Icons.Default.Timeline), Triple("Opportunity Radar", "Search for real opportunities that fit your circumstances.", Icons.Default.Radar), Triple("Reality Gap", "Identify what is missing between today and your goal.", Icons.Default.Difference), Triple("History", "Review decisions, outcomes, achievements and lessons.", Icons.Default.History))
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("The Architect", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Your strategic intelligence centre", color = Muted) }
        items(items) { item -> Surface(color = Color.White, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) { Icon(item.third, contentDescription = null, tint = Green, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(14.dp)); Column { Text(item.first, fontWeight = FontWeight.SemiBold); Text(item.second, color = Muted, style = MaterialTheme.typography.bodySmall); Text("Planned for a later development phase", color = Green, style = MaterialTheme.typography.labelSmall) } } } }
    }
}

@Composable
private fun SettingsDialog(onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Settings") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Personal profile and AI memory", fontWeight = FontWeight.SemiBold)
            Text("Notifications and alarms")
            Text("Privacy and history controls")
            Divider()
            Text("SMS TASK MESSENGER", fontWeight = FontWeight.Bold, color = Ink)
            Text("Reserved interface only. SMS sending, number verification and message queues are disabled in this version.", color = Muted, style = MaterialTheme.typography.bodySmall)
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Master switch", modifier = Modifier.weight(1f)); Switch(checked = false, onCheckedChange = {}, enabled = false) }
            Text("Not activated", color = Muted, style = MaterialTheme.typography.labelSmall)
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } })
}

@Composable
private fun HeaderWithAction(title: String, subtitle: String, action: String, onAction: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall) }; TextButton(onClick = onAction) { Icon(Icons.Default.Add, null); Text(action) } }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Ink); Spacer(Modifier.weight(1f)); Text(subtitle, style = MaterialTheme.typography.labelSmall, color = Muted) } }

@Composable
private fun MiniStat(label: String, value: String, modifier: Modifier) { Surface(modifier, color = Color.White, shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(13.dp)) { Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text(label, color = Muted, style = MaterialTheme.typography.labelSmall) } } }

@Composable
private fun EmptyState(title: String, body: String) { Surface(color = Color.White, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Green); Text(title, fontWeight = FontWeight.SemiBold); Text(body, color = Muted, style = MaterialTheme.typography.bodySmall) } } }

@Composable
private fun AddItemDialog(title: String, hint: String, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var description by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(name, { name = it }, label = { Text(hint) }, singleLine = true); OutlinedTextField(description, { description = it }, label = { Text("Additional context (optional)") }) } }, confirmButton = { TextButton(onClick = { onSave(name, description) }, enabled = name.isNotBlank()) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

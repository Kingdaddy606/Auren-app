package com.auren.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.auren.app.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AurenViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AurenDatabase.get(app).dao()
    val goals = dao.goals().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val projects = dao.projects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val tasks = dao.tasks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val contextEntries = dao.contextEntries().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val messages = dao.messages().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val commitments = dao.commitments().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addGoal(title: String, description: String) = viewModelScope.launch { if (title.isNotBlank()) dao.addGoal(GoalEntity(title = title.trim(), description = description.trim())) }
    fun addProject(title: String, description: String) = viewModelScope.launch { if (title.isNotBlank()) dao.addProject(ProjectEntity(title = title.trim(), description = description.trim())) }
    fun addTask(title: String) = viewModelScope.launch { if (title.isNotBlank()) dao.addTask(TaskEntity(title = title.trim())) }
    fun deleteGoal(id: Long) = viewModelScope.launch { dao.deleteGoal(id) }
    fun deleteProject(id: Long) = viewModelScope.launch { dao.deleteProject(id) }
    fun updateTask(id: Long, percent: Int) = viewModelScope.launch { dao.updateTaskProgress(id, percent, if (percent == 100) "AWAITING_REVIEW" else "IN_PROGRESS") }
    fun saveMessage(text: String) = viewModelScope.launch {
        if (text.isNotBlank()) {
            dao.addMessage(MessageEntity(role = "USER", content = text.trim()))
            dao.addContext(ContextEntity(category = "CONVERSATION_NOTE", content = text.trim(), permanence = "UNCLASSIFIED"))
        }
    }
}

# AUREN — Real App Foundation v1.0

A fresh native Android foundation for AUREN, the user's personal AI-directed operating system. This is not the earlier to-do-list prototype.

## Included in this release
- Five-section navigation: Today, Goals, Projects, AI Assistant, The Architect.
- Premium light visual system with restrained green accents.
- Separate overall ambition and daily performance progress displays.
- Weekly stock-style rate-change position reserved; no fabricated percentage is shown before sufficient performance history exists.
- Local Room database for goals, projects, tasks, personal-context notes, conversation messages and commitments.
- AI conversation screen that saves messages locally as context notes.
- Reserved SMS Task Messenger settings interface; sending, number verification and queues are disabled.
- Goal and project entry for initial profile setup.

## Important honest limitations
This is the first foundation release, not the finished AUREN system. It does not yet include a connected AI model, semantic memory retrieval, automatic task generation/replanning, alarms, timers, completion-review workflow, scoring, badge engine, real opportunity searches, Life Simulator or Reality Gap. The chat explicitly identifies that the AI service is not connected. Saved chat text is stored locally but is not yet understood or acted upon by an AI.

## Technical foundation
- Kotlin, Jetpack Compose, Material 3
- Room / SQLite local database
- Application ID: `com.auren.app`
- Minimum Android: 8.0 (API 26)
- Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3

## Build
Use the GitHub Actions workflow supplied separately in the conversation. The workflow extracts this project and builds `app-debug.apk`.

## Update/install note
The application ID is `com.auren.app`. Debug builds generated on different GitHub runners may have different debug-signing certificates. If Android refuses to update an older debug APK, uninstall the older app before installing this first foundation build. A stable signing setup should be introduced before repeated upgrade testing.

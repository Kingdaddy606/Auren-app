# AUREN AI Control & Ranks — v1.2

Personal Android productivity system. Package: `com.auren.app`.

## Included in this release
- Cloudflare Workers AI chat connection with encrypted local credential storage.
- Structured AI control actions: create goals, projects and tasks; update task details, progress and schedules; update projects; save context; update profile name.
- App records are supplied to the AI with their real IDs. The app applies only supported actions and reports what it actually changed.
- Personal profile name saved locally and included in AI context.
- Pure-white interface with dark purple aura surfaces and purple accent system.
- Generated AUREN launcher icon and animated in-app launch splash.
- Overall Journey moved into The Architect screen.
- Rank ladder: Rose Badge, Growth Milestone, Comeback Award, Unstoppable. Rank promotion thresholds: 18/43/68/92. Demotion thresholds: 18/43/68/78, with current rank persisted locally.
- SMS remains reserved and disabled.

## Important current limitations
- The rank score is an initial rolling 14-day score based on assessed task completion percentages and penalties. It is not yet a fully audited scoring ledger.
- Overall Journey remains at 0% until meaningful milestone/evidence tracking is implemented. This avoids inventing progress from ordinary task check-offs.
- AI can create and update task schedule timestamps, but Android preparation alarms, exact start alarms, countdown timers and reboot recovery are not implemented in this build.
- Opportunity Radar, Life Simulator, Reality Gap and History are visual entry points, not fully connected engines in this release.
- The app is local-first. Do not uninstall an older build if you need its local data.
- The app has not been independently compiled in this environment; GitHub Actions performs the build.

## Cloudflare Worker update required for AI control
The app can only execute structured AI actions if the Worker uses the updated system prompt. Open your Cloudflare Worker `auren-ai-gateway`, replace its `worker.js` contents with `cloudflare/worker.js` from this ZIP, and Deploy. Keep the existing `AI` binding and `AUREN_API_KEY` secret. Do not put the server secret in the APK or GitHub repository.

## Build
- Java 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- compileSdk 35, minSdk 26
- Run `gradle --no-daemon assembleDebug` from this project root.


## Autonomous planning build (v1.3)

- On app launch, AUREN checks whether a successful daily plan has been generated for the device's current local date.
- If a gateway token is configured and at least one ambition exists, it sends a daily planning instruction to the Worker.
- The day is marked planned only after a successful gateway response; a failed request can be retried on a later app launch.
- After ordinary meaningful chat messages, the Worker is instructed to reassess tasks and may create, update, reschedule or remove justified unfinished tasks.
- Completed tasks are protected from AI deletion.
- This is foreground/app-open automation, not a background scheduled job: AUREN does not wake itself at a particular morning time if the user does not open the app.

### Build
Upload `AUREN_Source_For_Testing.zip` to the repository root and save `AUREN_Build_Workflow.yml` as `.github/workflows/build-auren.yml`. Run **Build AUREN Autonomous Planner APK** from GitHub Actions.

### Required Worker setup
Deploy `cloudflare/worker.js` with a Workers AI binding named `AI` and a secret named `AUREN_API_KEY`. In AUREN Settings, save the Worker HTTPS endpoint ending in `/` and the same access secret. Never commit the secret.

### Testing caveat
The source archive is ZIP-validated and the Worker JavaScript passes `node --check`. Android compilation and physical-device behaviour still require the GitHub Actions build and device test.

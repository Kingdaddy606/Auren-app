package com.auren.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.auren.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Locale

class AurenViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AurenDatabase.get(app).dao()
    private val secureStore = AurenSecureStore(app)
    private val prefs = app.getSharedPreferences("auren_profile", android.content.Context.MODE_PRIVATE)
    private val _profileName = MutableStateFlow(prefs.getString("name", "") ?: "")
    val profileName: StateFlow<String> = _profileName.asStateFlow()

    fun saveProfileName(name: String) {
        val clean = name.trim().take(40)
        prefs.edit().putString("name", clean).apply()
        _profileName.value = clean
    }
    fun evaluateRank(score: Int): Pair<Int, String> {
        val names = listOf("Building Momentum", "Rose Badge", "Growth Milestone", "Comeback Award", "Unstoppable")
        val promotion = listOf(0, 18, 43, 68, 92)
        val demotion = listOf(0, 18, 43, 68, 78)
        var level = prefs.getInt("rank_level", 0).coerceIn(0, 4)
        while (level < 4 && score >= promotion[level + 1]) level++
        while (level > 0 && score < demotion[level]) level--
        prefs.edit().putInt("rank_level", level).apply()
        return level to names[level]
    }
    val goals = dao.goals().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val projects = dao.projects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val tasks = dao.tasks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val contextEntries = dao.contextEntries().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val messages = dao.messages().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val commitments = dao.commitments().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _aiStatus = MutableStateFlow("Connect your Cloudflare gateway in Settings to start chatting.")
    val aiStatus: StateFlow<String> = _aiStatus.asStateFlow()
    private val _sending = MutableStateFlow(false)
    val sending: StateFlow<Boolean> = _sending.asStateFlow()

    fun gatewayEndpoint(): String = secureStore.endpoint()
    fun hasGatewayToken(): Boolean = secureStore.token().isNotBlank()

    fun saveGatewaySettings(endpoint: String, token: String) {
        val cleanEndpoint = endpoint.trim()
        if (cleanEndpoint.startsWith("https://") && cleanEndpoint.endsWith("/") && token.isNotBlank()) {
            secureStore.saveEndpoint(cleanEndpoint)
            secureStore.saveToken(token)
            _aiStatus.value = "Gateway settings saved securely on this device. You can now chat with AUREN."
        } else {
            _aiStatus.value = "Enter a valid HTTPS gateway URL ending in / and your access secret."
        }
    }

    fun addGoal(title: String, description: String) = viewModelScope.launch { if (title.isNotBlank()) dao.addGoal(GoalEntity(title = title.trim(), description = description.trim())) }
    fun addProject(title: String, description: String) = viewModelScope.launch { if (title.isNotBlank()) dao.addProject(ProjectEntity(title = title.trim(), description = description.trim())) }
    fun addTask(title: String) = viewModelScope.launch { if (title.isNotBlank()) dao.addTask(TaskEntity(title = title.trim())) }
    internal suspend fun executeAiActions(actions: JSONArray): List<String> {
        val completed = mutableListOf<String>()
        for (i in 0 until minOf(actions.length(), 12)) {
            val a = actions.optJSONObject(i) ?: continue
            when (a.optString("type").uppercase()) {
                "CREATE_GOAL" -> {
                    val title = a.optString("title").trim()
                    if (title.isNotBlank()) { dao.addGoal(GoalEntity(title = title, description = a.optString("description"))); completed += "Created ambition: $title" }
                }
                "UPDATE_GOAL" -> {
                    val id = a.optLong("id", -1L)
                    if (id > 0) {
                        val title = a.optString("title", "Updated ambition").take(120)
                        dao.updateGoalDetails(id, title, a.optString("description"))
                        completed += "Updated ambition: $title"
                    }
                }
                "CREATE_PROJECT" -> {
                    val title = a.optString("title").trim()
                    if (title.isNotBlank()) {
                        val requestedGoalId = if (a.has("goalId") && !a.isNull("goalId")) a.optLong("goalId") else null
                        val goalId = requestedGoalId?.takeIf { id -> dao.allGoals().any { it.id == id } }
                        dao.addProject(ProjectEntity(goalId = goalId, title = title, description = a.optString("description")))
                        completed += "Created project: $title"
                    }
                }
                "CREATE_TASK" -> {
                    val title = a.optString("title").trim()
                    if (title.isNotBlank()) {
                        val projectId = if (a.has("projectId") && !a.isNull("projectId")) a.optLong("projectId") else null
                        val knownProjects = dao.allProjects()
                        val validProjectId = projectId?.takeIf { id -> knownProjects.any { it.id == id } }
                        val existingTasks = dao.tasks().first()
                        val duplicate = existingTasks.any { it.status !in listOf("COMPLETED", "CANCELLED") && it.title.trim().equals(title, ignoreCase = true) }
                        if (!duplicate) {
                            val minutes = a.optInt("estimatedMinutes", 30).coerceIn(5, 720)
                            val scheduledAt = if (a.has("scheduledAt") && !a.isNull("scheduledAt")) a.optLong("scheduledAt") else null
                            dao.addTask(TaskEntity(title = title, projectId = validProjectId, estimatedMinutes = minutes, scheduledAt = scheduledAt))
                            completed += "Created task: $title"
                        }
                    }
                }
                "DELETE_TASK" -> {
                    val id = a.optLong("id", -1L)
                    if (id > 0L) {
                        val existing = dao.tasks().first().firstOrNull { it.id == id }
                        if (existing != null && existing.status != "COMPLETED") {
                            val deleted = dao.deleteTask(id)
                            if (deleted > 0) completed += "Removed obsolete task: ${existing.title}"
                        }
                    }
                }
                "UPDATE_TASK" -> {
                    val id = a.optLong("id", -1L)
                    if (id > 0) {
                        val existing = dao.tasks().let { flow -> flow.first().firstOrNull { it.id == id } }
                        if (existing != null) {
                            val percent = a.optInt("completionPercent", existing.completionPercent).coerceIn(0, 100)
                            val status = a.optString("status", existing.status).uppercase().takeIf { it in listOf("PLANNED", "IN_PROGRESS", "AWAITING_REVIEW", "COMPLETED", "POSTPONED", "CANCELLED") } ?: existing.status
                            val title = a.optString("title", existing.title)
                            val mins = a.optInt("estimatedMinutes", existing.estimatedMinutes).coerceIn(5, 720)
                            val time = if (a.optBoolean("clearSchedule", false)) null else if (a.has("scheduledAt") && !a.isNull("scheduledAt")) a.optLong("scheduledAt") else existing.scheduledAt
                            dao.updateTaskDetails(id, title, time, mins, status)
                            dao.updateTaskProgress(id, percent, status)
                            completed += "Updated task: $title"
                        }
                    }
                }
                "UPDATE_PROJECT" -> {
                    val id = a.optLong("id", -1L)
                    if (id > 0) {
                        val title = a.optString("title", "Updated project").take(120)
                        dao.updateProjectDetails(id, title, a.optString("description"))
                        completed += "Updated project: $title"
                    }
                }
                "CREATE_COMMITMENT" -> {
                    val title = a.optString("title").trim()
                    val starts = a.optLong("startsAt", 0L)
                    val ends = a.optLong("endsAt", 0L)
                    if (title.isNotBlank() && starts > 0L && ends > starts) {
                        dao.addCommitment(CommitmentEntity(title = title, startsAt = starts, endsAt = ends, recurrence = a.optString("recurrence", "NONE"), notes = a.optString("notes")))
                        completed += "Saved commitment: $title"
                    }
                }
                "SAVE_CONTEXT" -> {
                    val content = a.optString("content").trim()
                    if (content.isNotBlank()) { dao.addContext(ContextEntity(category = a.optString("category", "PERSONAL_NOTE"), content = content, permanence = a.optString("permanence", "UNCLASSIFIED"))); completed += "Saved personal context" }
                }
                "SET_PROFILE_NAME" -> {
                    val name = a.optString("name").trim()
                    if (name.isNotBlank()) { saveProfileName(name); completed += "Updated profile name" }
                }
            }
        }
        return completed
    }
    fun clearAiMemory() = viewModelScope.launch {
        dao.clearPersonalContext()
        dao.clearConversationMessages()
        prefs.edit().remove("name").apply()
        _profileName.value = ""
        _aiStatus.value = "AI memory and conversation history cleared. AUREN is ready for a fresh start."
    }

    fun deleteGoal(id: Long) = viewModelScope.launch { dao.deleteGoal(id) }
    fun deleteProject(id: Long) = viewModelScope.launch { dao.deleteProject(id) }
    fun updateTask(id: Long, percent: Int) = viewModelScope.launch { dao.updateTaskProgress(id, percent, if (percent == 100) "AWAITING_REVIEW" else "IN_PROGRESS") }

    /** Runs once per local calendar day. The date is committed only after a valid gateway response. */
    fun runDailyPlanningIfNeeded() = viewModelScope.launch {
        val token = secureStore.token()
        if (token.isBlank() || _sending.value) return@launch
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(java.util.Date())
        if (prefs.getString("last_successful_daily_plan", "") == today) return@launch
        if (dao.allGoals().isEmpty()) {
            _aiStatus.value = "Tell AUREN about an ambition first. It will then build your daily plan."
            return@launch
        }
        sendMessage("[AUREN DAILY PLANNING CYCLE] Review my ambitions, current tasks, recent conversation, saved context, commitments and recent performance. You own my daily task list. Decide what I should realistically work on today. Create, update, reschedule or remove tasks when justified. Use no more than five priority tasks, avoid duplicates, preserve completed history, and do not invent times when availability is unknown. Explain your decisions and ask only if a critical scheduling fact is missing.", successfulPlanningDate = today)
    }

    fun sendMessage(text: String) = sendMessage(text, null)

    private fun sendMessage(text: String, successfulPlanningDate: String?) = viewModelScope.launch {
        val clean = text.trim()
        if (clean.isBlank() || _sending.value) return@launch
        dao.addMessage(MessageEntity(role = "USER", content = clean))
        dao.addContext(ContextEntity(category = "CONVERSATION_NOTE", content = clean, permanence = "UNCLASSIFIED"))

        val token = secureStore.token()
        if (token.isBlank()) {
            _aiStatus.value = "Your message was saved. Add your AUREN access secret in Settings to receive AI replies."
            return@launch
        }

        _sending.value = true
        _aiStatus.value = "AUREN is considering your message and relevant personal context…"
        try {
            val contextText = withContext(Dispatchers.IO) {
                val goalsNow = dao.allGoals()
                val projectsNow = dao.allProjects()
                val contextNow = dao.recentContext()
                val commitmentsNow = dao.allCommitments()
                buildString {
                    appendLine("CURRENT LOCAL DEVICE TIME: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm z", Locale.getDefault()).format(java.util.Date())}")
                    appendLine("PROFILE NAME: ${profileName.value.ifBlank { "Not provided" }}")
                    appendLine("AUTONOMY CONTRACT: You own day-to-day task-list maintenance. After EVERY meaningful user message, reassess the plan using the full conversation and app records. When the user's circumstances, priorities, availability, energy, or goals-in-progress change, proactively create, update, reschedule, or remove tasks without asking the user to specify each edit. Do not make changes merely to appear active. Preserve useful work and completed history. Delete only clearly obsolete, duplicate, or superseded unfinished tasks; prefer postponing/cancelling when that preserves useful history. Never delete completed tasks. Never change long-term goals or delete projects without explicit permission. Do not mark tasks complete unless the user reports completion. Keep a realistic workload and avoid duplicate active tasks. Return ONLY valid JSON with keys reply and actions. Allowed actions: CREATE_GOAL {title,description}; CREATE_PROJECT {title,description,goalId}; CREATE_TASK {title,projectId,estimatedMinutes,scheduledAt}; UPDATE_TASK {id,title,completionPercent,status,estimatedMinutes,scheduledAt,clearSchedule}; DELETE_TASK {id,reason}; UPDATE_PROJECT {id,title,description}; UPDATE_GOAL {id,title,description}; CREATE_COMMITMENT {title,startsAt,endsAt,recurrence,notes}; SAVE_CONTEXT {content,category,permanence}; SET_PROFILE_NAME {name}. Use existing IDs only. Times are Unix milliseconds; use null when unknown. Use clearSchedule=true to remove a task time. Never claim an action happened unless included. If no change is justified, return actions: [].")
                    appendLine("USER AMBITIONS:")
                    goalsNow.forEach { appendLine("- ID ${it.id}: ${it.title}: ${it.description}") }
                    appendLine("PROJECTS:")
                    projectsNow.forEach { appendLine("- ID ${it.id}: ${it.title}: ${it.description}") }
                    appendLine("CURRENT TASKS:")
                    dao.tasks().let { flow -> flow.first() }.forEach { appendLine("- ID ${it.id}; ${it.title}; status=${it.status}; completion=${it.completionPercent}%; scheduledAt=${it.scheduledAt}; duration=${it.estimatedMinutes}m; projectId=${it.projectId}") }
                    appendLine("SAVED PERSONAL CONTEXT:")
                    contextNow.forEach { appendLine("- [${it.category}; ${it.permanence}] ${it.content}") }
                    appendLine("COMMITMENTS:")
                    commitmentsNow.forEach { appendLine("- ${it.title}; starts ${it.startsAt}; ends ${it.endsAt}; ${it.recurrence}; ${it.notes}") }
                }.take(10000)
            }
            val history = withContext(Dispatchers.IO) { dao.recentMessages().asReversed() }
            val apiMessages = history.mapNotNull { message ->
                val role = when (message.role) { "USER" -> "user"; "ASSISTANT" -> "assistant"; else -> null }
                role?.let { it to message.content }
            }.takeLast(20)
            val rawReply = withContext(Dispatchers.IO) {
                AurenGatewayClient.send(secureStore.endpoint(), token, apiMessages, contextText)
            }
            val replyObject = extractJsonObject(rawReply)
            val reply = if (replyObject != null) replyObject.optString("reply", "AUREN has processed your request.") else rawReply
            val actions = replyObject?.optJSONArray("actions") ?: JSONArray()
            val applied = withContext(Dispatchers.IO) { executeAiActions(actions) }
            val visibleReply = buildString {
                append(reply.ifBlank { "AUREN has processed your request." })
                if (applied.isNotEmpty()) {
                    append("\n\nUpdated in AUREN:")
                    applied.forEach { append("\n• ").append(it) }
                }
            }
            dao.addMessage(MessageEntity(role = "ASSISTANT", content = visibleReply))
            if (successfulPlanningDate != null) {
                prefs.edit().putString("last_successful_daily_plan", successfulPlanningDate).apply()
            }
            _aiStatus.value = if (applied.isEmpty()) "AUREN replied. No app records needed changing." else "AUREN completed ${applied.size} app action(s)."
        } catch (error: Exception) {
            _aiStatus.value = "AUREN couldn't reply: ${error.message ?: "Unknown connection error"}"
        } finally {
            _sending.value = false
        }
    }

    private fun extractJsonObject(raw: String): JSONObject? {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return try { JSONObject(raw.substring(start, end + 1)) } catch (_: Exception) { null }
    }
}

package com.auren.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import com.auren.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Persistent daily planning chain. WorkManager restores scheduled work after reboot. */
object AurenDailyPlanner {
    const val CHANNEL_ID = "auren_daily_plan"
    private const val UNIQUE_WORK = "auren_daily_plan_chain"

    fun ensureScheduled(context: Context) {
        val request = OneTimeWorkRequestBuilder<AurenDailyPlanWorker>()
            .setInitialDelay(millisUntilNextMorning(), TimeUnit.MILLISECONDS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .addTag(UNIQUE_WORK).build()
        WorkManager.getInstance(context).enqueueUniqueWork(UNIQUE_WORK, ExistingWorkPolicy.KEEP, request)
        createChannel(context)
    }

    internal fun scheduleNext(context: Context) {
        val request = OneTimeWorkRequestBuilder<AurenDailyPlanWorker>()
            .setInitialDelay(24, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .addTag(UNIQUE_WORK).build()
        WorkManager.getInstance(context).enqueueUniqueWork(UNIQUE_WORK, ExistingWorkPolicy.APPEND_OR_REPLACE, request)
    }

    private fun millisUntilNextMorning(): Long {
        val now = Calendar.getInstance(); val next = now.clone() as Calendar
        next.set(Calendar.HOUR_OF_DAY, 7); next.set(Calendar.MINUTE, 0); next.set(Calendar.SECOND, 0); next.set(Calendar.MILLISECOND, 0)
        if (next.timeInMillis <= now.timeInMillis) next.add(Calendar.DAY_OF_YEAR, 1)
        return next.timeInMillis - now.timeInMillis
    }

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Daily AUREN plan", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Your AI-prepared daily priorities and task reminders"
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    fun notifyPlan(context: Context, title: String, preview: String) {
        createChannel(context)
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val intent = Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP }
        val pending = PendingIntent.getActivity(context, 701, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_auren).setContentTitle(title).setContentText(preview)
            .setStyle(NotificationCompat.BigTextStyle().bigText(preview)).setContentIntent(pending)
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
        NotificationManagerCompat.from(context).notify(701, notification)
    }
}

class AurenDailyPlanWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val store = AurenSecureStore(applicationContext)
            val token = store.token()
            if (token.isBlank()) { AurenDailyPlanner.scheduleNext(applicationContext); return@withContext Result.success() }
            val dao = AurenDatabase.get(applicationContext).dao()
            val goals = dao.allGoals()
            if (goals.isEmpty()) { AurenDailyPlanner.scheduleNext(applicationContext); return@withContext Result.success() }
            val prefs = applicationContext.getSharedPreferences("auren_profile", Context.MODE_PRIVATE)
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            if (prefs.getString("last_successful_daily_plan", "") == today) {
                AurenDailyPlanner.notifyPlan(applicationContext, "AUREN — Your day is ready", "Open AUREN to review today's priorities.")
                AurenDailyPlanner.scheduleNext(applicationContext); return@withContext Result.success()
            }
            val tasks = dao.allTasks(); val projects = dao.allProjects(); val commitments = dao.allCommitments(); val contextItems = dao.recentContext(); val history = dao.recentMessages().asReversed()
            val context = buildString {
                appendLine("AUTOMATED MORNING PLANNING. Local date: $today. Prepare today's plan without requiring the user to open the app.")
                appendLine("Profile: ${prefs.getString("name", "")}")
                appendLine("Goals:"); goals.forEach { appendLine("ID ${it.id}: ${it.title} — ${it.description}") }
                appendLine("Projects:"); projects.forEach { appendLine("ID ${it.id}: ${it.title} — ${it.description}") }
                appendLine("Tasks:"); tasks.forEach { appendLine("ID ${it.id}: ${it.title}; ${it.status}; ${it.completionPercent}%; time=${it.scheduledAt}; duration=${it.estimatedMinutes}m; project=${it.projectId}") }
                appendLine("Commitments:"); commitments.forEach { appendLine("${it.title}: ${it.startsAt}-${it.endsAt} ${it.recurrence} ${it.notes}") }
                appendLine("Saved context:"); contextItems.forEach { appendLine("${it.category}: ${it.content}") }
                appendLine("Recent conversation:"); history.takeLast(16).forEach { appendLine("${it.role}: ${it.content}") }
                appendLine("You own the task list. Create, update, reschedule, or delete obsolete unfinished tasks as justified. Never delete or alter completed tasks. Avoid duplicates. Limit today's priority workload to five realistic tasks. Do not invent commitments or time slots. Keep all changes in actions. Return ONLY JSON: {\"reply\":\"short daily summary\",\"actions\":[...]}. Allowed action types: CREATE_TASK {title,projectId,estimatedMinutes,scheduledAt}; UPDATE_TASK {id,title,estimatedMinutes,scheduledAt,clearSchedule,status,completionPercent}; DELETE_TASK {id,reason}. Times are Unix milliseconds; use null if unknown.")
            }.take(14000)
            val messages = history.mapNotNull { m -> when(m.role) { "USER" -> "user" to m.content; "ASSISTANT" -> "assistant" to m.content; else -> null } }.takeLast(20).toMutableList()
            messages.add("user" to "[AUTOMATIC DAILY PLAN] Generate and apply today's plan now. Consider yesterday's performance and adapt workload.")
            val raw = AurenGatewayClient.send(store.endpoint(), token, messages, context)
            val json = JSONObject(raw.substring(raw.indexOf('{').coerceAtLeast(0), raw.lastIndexOf('}') + 1))
            val actions = json.optJSONArray("actions") ?: JSONArray()
            val applied = mutableListOf<String>()
            for (i in 0 until actions.length()) {
                val a = actions.optJSONObject(i) ?: continue
                when (a.optString("type").uppercase()) {
                    "CREATE_TASK" -> {
                        val title = a.optString("title").trim(); if (title.isNotBlank()) {
                            val projectId = a.optLong("projectId", 0L).takeIf { id -> projects.any { it.id == id } }
                            val time = if (a.isNull("scheduledAt")) null else a.optLong("scheduledAt").takeIf { it > 0 }
                            if (tasks.none { it.status !in listOf("COMPLETED", "CANCELLED") && it.title.equals(title, true) }) {
                                dao.addTask(TaskEntity(projectId = projectId, title = title, scheduledAt = time, estimatedMinutes = a.optInt("estimatedMinutes", 30).coerceIn(5, 720))); applied.add(title)
                            }
                        }
                    }
                    "UPDATE_TASK" -> {
                        val old = tasks.firstOrNull { it.id == a.optLong("id", -1) && it.status != "COMPLETED" } ?: continue
                        val status = a.optString("status", old.status).uppercase().takeIf { it in listOf("PLANNED", "IN_PROGRESS", "POSTPONED", "CANCELLED", "AWAITING_REVIEW") } ?: old.status
                        val time = if (a.optBoolean("clearSchedule")) null else if (a.has("scheduledAt") && !a.isNull("scheduledAt")) a.optLong("scheduledAt") else old.scheduledAt
                        dao.updateTaskDetails(old.id, a.optString("title", old.title), time, a.optInt("estimatedMinutes", old.estimatedMinutes).coerceIn(5,720), status); applied.add(a.optString("title", old.title))
                    }
                    "DELETE_TASK" -> { val old = tasks.firstOrNull { it.id == a.optLong("id", -1) && it.status != "COMPLETED" }; if (old != null && dao.deleteTask(old.id) > 0) applied.add("Removed ${old.title}") }
                }
            }
            val summary = json.optString("reply", "Your priorities have been prepared.").ifBlank { "Your priorities have been prepared." }
            dao.addMessage(MessageEntity(role = "ASSISTANT", content = "[Daily plan $today] $summary"))
            prefs.edit().putString("last_successful_daily_plan", today).apply()
            val first = (dao.allTasks().filter { it.status !in listOf("COMPLETED", "CANCELLED") }.sortedBy { it.scheduledAt ?: Long.MAX_VALUE }).firstOrNull()
            val preview = first?.let { "First priority: ${it.title}. ${applied.size} plan change(s) made." } ?: summary.take(180)
            AurenDailyPlanner.notifyPlan(applicationContext, "AUREN — Your day is ready", preview)
            AurenDailyPlanner.scheduleNext(applicationContext)
            Result.success()
        } catch (e: Exception) {
            // WorkManager retries transient gateway/network errors; it does not mark the day complete.
            Result.retry()
        }
    }
}

package com.auren.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "goals")
data class GoalEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val description: String = "", val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "projects")
data class ProjectEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val goalId: Long? = null, val title: String, val description: String = "", val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "tasks")
data class TaskEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val projectId: Long? = null, val title: String, val scheduledAt: Long? = null, val estimatedMinutes: Int = 30, val completionPercent: Int = 0, val status: String = "PLANNED", val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "personal_context")
data class ContextEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val category: String, val content: String, val permanence: String = "GENERAL", val updatedAt: Long = System.currentTimeMillis())

@Entity(tableName = "conversation_messages")
data class MessageEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val role: String, val content: String, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "commitments")
data class CommitmentEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val startsAt: Long, val endsAt: Long, val recurrence: String = "NONE", val notes: String = "")

@Dao
interface AurenDao {
    @Query("SELECT * FROM goals ORDER BY createdAt DESC") fun goals(): Flow<List<GoalEntity>>
    @Query("SELECT * FROM projects ORDER BY createdAt DESC") fun projects(): Flow<List<ProjectEntity>>
    @Query("SELECT * FROM tasks ORDER BY CASE WHEN scheduledAt IS NULL THEN 1 ELSE 0 END, scheduledAt") fun tasks(): Flow<List<TaskEntity>>
    @Query("SELECT * FROM personal_context ORDER BY updatedAt DESC") fun contextEntries(): Flow<List<ContextEntity>>
    @Query("SELECT * FROM conversation_messages ORDER BY createdAt") fun messages(): Flow<List<MessageEntity>>
    @Query("SELECT * FROM commitments ORDER BY startsAt") fun commitments(): Flow<List<CommitmentEntity>>
    @Query("SELECT * FROM goals ORDER BY createdAt DESC") suspend fun allGoals(): List<GoalEntity>
    @Query("SELECT * FROM tasks ORDER BY scheduledAt") suspend fun allTasks(): List<TaskEntity>
    @Query("SELECT * FROM projects ORDER BY createdAt DESC") suspend fun allProjects(): List<ProjectEntity>
    @Query("SELECT * FROM personal_context ORDER BY updatedAt DESC LIMIT 30") suspend fun recentContext(): List<ContextEntity>
    @Query("SELECT * FROM commitments ORDER BY startsAt LIMIT 30") suspend fun allCommitments(): List<CommitmentEntity>
    @Query("SELECT * FROM conversation_messages ORDER BY createdAt DESC LIMIT 20") suspend fun recentMessages(): List<MessageEntity>
    @Insert suspend fun addGoal(item: GoalEntity)
    @Insert suspend fun addProject(item: ProjectEntity)
    @Insert suspend fun addTask(item: TaskEntity)
    @Insert suspend fun addContext(item: ContextEntity)
    @Insert suspend fun addMessage(item: MessageEntity)
    @Insert suspend fun addCommitment(item: CommitmentEntity)
    @Query("DELETE FROM personal_context") suspend fun clearPersonalContext()
    @Query("DELETE FROM conversation_messages") suspend fun clearConversationMessages()
    @Query("DELETE FROM goals WHERE id = :id") suspend fun deleteGoal(id: Long)
    @Query("DELETE FROM projects WHERE id = :id") suspend fun deleteProject(id: Long)
    @Query("DELETE FROM tasks WHERE id = :id AND status != 'COMPLETED'") suspend fun deleteTask(id: Long): Int
    @Query("UPDATE tasks SET completionPercent = :percent, status = :status WHERE id = :id") suspend fun updateTaskProgress(id: Long, percent: Int, status: String)
    @Query("UPDATE tasks SET title = :title, scheduledAt = :scheduledAt, estimatedMinutes = :minutes, status = :status WHERE id = :id") suspend fun updateTaskDetails(id: Long, title: String, scheduledAt: Long?, minutes: Int, status: String)
    @Query("UPDATE projects SET title = :title, description = :description WHERE id = :id") suspend fun updateProjectDetails(id: Long, title: String, description: String)
    @Query("UPDATE goals SET title = :title, description = :description WHERE id = :id") suspend fun updateGoalDetails(id: Long, title: String, description: String)
}

@Database(entities = [GoalEntity::class, ProjectEntity::class, TaskEntity::class, ContextEntity::class, MessageEntity::class, CommitmentEntity::class], version = 1, exportSchema = false)
abstract class AurenDatabase : RoomDatabase() {
    abstract fun dao(): AurenDao
    companion object {
        @Volatile private var INSTANCE: AurenDatabase? = null
        fun get(context: Context): AurenDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AurenDatabase::class.java, "auren_personal.db").build().also { INSTANCE = it }
        }
    }
}

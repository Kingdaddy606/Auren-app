# AUREN v1.0 — Foundation

Personal-use Android app foundation built with Kotlin, Jetpack Compose and Room (SQLite).

## Included
- Today dashboard
- Create and delete goals
- Create and delete projects
- Create, complete, uncomplete and delete tasks
- Local persistent storage (data remains after closing/reopening the app)
- Basic task activity history

## Build using GitHub Actions
1. Upload `AUREN_v1_Foundation.zip` to the root of your GitHub repository.
2. Create `.github/workflows/build-auren-apk.yml` using the workflow supplied in the chat.
3. Run the workflow from the Actions tab.
4. Download the `AUREN-v1.0-debug` artifact.

The workflow extracts this ZIP into the repository and builds the debug APK with JDK 17 and Gradle 8.9.

This is the foundation milestone. Scheduling, alarms, AI, milestone progress, scoring, badges, cloud sync and SMS are not included yet and will be added in later tested phases.

package com.auren.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "goals")
data class Goal(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val description: String = "", val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "projects")
data class Project(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val goalId: Long? = null, val description: String = "", val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "tasks")
data class TaskItem(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val projectId: Long? = null, val goalId: Long? = null, val dueDate: String = "", val durationMinutes: Int = 30, val isDone: Boolean = false, val createdAt: Long = System.currentTimeMillis())

@Dao interface AurenDao {
    @Query("SELECT * FROM goals ORDER BY createdAt DESC") fun goals(): Flow<List<Goal>>
    @Insert suspend fun addGoal(item: Goal)
    @Update suspend fun updateGoal(item: Goal)
    @Delete suspend fun deleteGoal(item: Goal)
    @Query("SELECT * FROM projects ORDER BY createdAt DESC") fun projects(): Flow<List<Project>>
    @Insert suspend fun addProject(item: Project)
    @Update suspend fun updateProject(item: Project)
    @Delete suspend fun deleteProject(item: Project)
    @Query("SELECT * FROM tasks ORDER BY isDone ASC, createdAt DESC") fun tasks(): Flow<List<TaskItem>>
    @Insert suspend fun addTask(item: TaskItem)
    @Update suspend fun updateTask(item: TaskItem)
    @Delete suspend fun deleteTask(item: TaskItem)
}

@Database(entities = [Goal::class, Project::class, TaskItem::class], version = 1, exportSchema = false)
abstract class AurenDatabase : RoomDatabase() {
    abstract fun dao(): AurenDao
    companion object {
        @Volatile private var INSTANCE: AurenDatabase? = null
        fun get(context: Context): AurenDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AurenDatabase::class.java, "auren_personal.db").build().also { INSTANCE = it }
        }
    }
}

# AUREN AI Connected v2

AUREN's next Android foundation, built with Kotlin, Jetpack Compose, Room and Cloudflare Workers AI.

## What's new in v2

- The AI Assistant now sends chat messages to the Cloudflare Worker gateway.
- AI replies are saved in the local Room conversation history.
- User messages are saved as personal context notes.
- Relevant local context is sent with each chat request: ambitions, projects, recent context notes and commitments.
- The app sends recent conversation turns so AUREN can follow the current discussion.
- Gateway URL and access token are configured from Settings; the token is encrypted at rest using Android Keystore and is not embedded in the APK source.
- HTTPS requests use the Android INTERNET permission.
- SMS remains a reserved, disabled interface. No SMS sending, verification, queue or backend is included.

## Cloudflare connection

Default Worker URL:

`https://auren-ai-gateway.pomorogbe465.workers.dev/`

After installing the APK:

1. Open AUREN.
2. Tap the profile/settings icon at the top right.
3. In **AUREN AI CONNECTION**, enter the Worker URL above.
4. Paste the value of your Cloudflare `AUREN_API_KEY` secret into the access-secret field.
5. Tap **Save connection**.
6. Open the AI tab and send a message.

The access token is stored encrypted with a key held by Android Keystore. Do not share it or include it in source code, screenshots, or GitHub files. Since the earlier token was disclosed in a chat, rotate it in Cloudflare before using AUREN regularly, then enter the replacement token in Settings.

## Important current limitations

This version connects real AI chat and passes relevant saved context. It does **not yet** give the AI authority to create or reschedule tasks, control Android alarms, or change the progress bars. Those require a separate deterministic planning/action layer and will be implemented in later phases. The AI must not claim it changed app data when it has only suggested a change.

The initial progress displays, goals/projects foundation and Architect placeholders remain from v1. Opportunity Radar, Life Simulator, Reality Gap, full History controls, alarms/timers and automated task management are not implemented yet.

## Build

- Android package: `com.auren.app`
- Minimum Android: API 26
- Compile/target SDK: 35
- Java: 17
- Gradle: 8.9
- Build command: `gradle --no-daemon assembleDebug`

The included GitHub Actions workflow expects `AUREN_AI_Connected_v2.zip` in the repository root.

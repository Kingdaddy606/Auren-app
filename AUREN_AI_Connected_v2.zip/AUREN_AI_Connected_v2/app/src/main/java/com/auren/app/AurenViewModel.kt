package com.auren.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.auren.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AurenViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AurenDatabase.get(app).dao()
    private val secureStore = AurenSecureStore(app)
    val goals = dao.goals().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val projects = dao.projects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val tasks = dao.tasks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val contextEntries = dao.contextEntries().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val messages = dao.messages().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val commitments = dao.commitments().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _aiStatus = MutableStateFlow("Connect your Cloudflare gateway in Settings to start chatting.")
    val aiStatus: StateFlow<String> = _aiStatus.asStateFlow()
    private val _sending = MutableStateFlow(false)
    val sending: StateFlow<Boolean> = _sending.asStateFlow()

    fun gatewayEndpoint(): String = secureStore.endpoint()
    fun hasGatewayToken(): Boolean = secureStore.token().isNotBlank()

    fun saveGatewaySettings(endpoint: String, token: String) {
        val cleanEndpoint = endpoint.trim()
        if (cleanEndpoint.startsWith("https://") && cleanEndpoint.endsWith("/") && token.isNotBlank()) {
            secureStore.saveEndpoint(cleanEndpoint)
            secureStore.saveToken(token)
            _aiStatus.value = "Gateway settings saved securely on this device. You can now chat with AUREN."
        } else {
            _aiStatus.value = "Enter a valid HTTPS gateway URL ending in / and your access secret."
        }
    }

    fun addGoal(title: String, description: String) = viewModelScope.launch { if (title.isNotBlank()) dao.addGoal(GoalEntity(title = title.trim(), description = description.trim())) }
    fun addProject(title: String, description: String) = viewModelScope.launch { if (title.isNotBlank()) dao.addProject(ProjectEntity(title = title.trim(), description = description.trim())) }
    fun addTask(title: String) = viewModelScope.launch { if (title.isNotBlank()) dao.addTask(TaskEntity(title = title.trim())) }
    fun deleteGoal(id: Long) = viewModelScope.launch { dao.deleteGoal(id) }
    fun deleteProject(id: Long) = viewModelScope.launch { dao.deleteProject(id) }
    fun updateTask(id: Long, percent: Int) = viewModelScope.launch { dao.updateTaskProgress(id, percent, if (percent == 100) "AWAITING_REVIEW" else "IN_PROGRESS") }

    fun sendMessage(text: String) = viewModelScope.launch {
        val clean = text.trim()
        if (clean.isBlank() || _sending.value) return@launch
        dao.addMessage(MessageEntity(role = "USER", content = clean))
        dao.addContext(ContextEntity(category = "CONVERSATION_NOTE", content = clean, permanence = "UNCLASSIFIED"))

        val token = secureStore.token()
        if (token.isBlank()) {
            _aiStatus.value = "Your message was saved. Add your AUREN access secret in Settings to receive AI replies."
            return@launch
        }

        _sending.value = true
        _aiStatus.value = "AUREN is considering your message and relevant personal context…"
        try {
            val contextText = withContext(Dispatchers.IO) {
                val goalsNow = dao.allGoals()
                val projectsNow = dao.allProjects()
                val contextNow = dao.recentContext()
                val commitmentsNow = dao.allCommitments()
                buildString {
                    appendLine("USER AMBITIONS:")
                    goalsNow.forEach { appendLine("- ${it.title}: ${it.description}") }
                    appendLine("PROJECTS:")
                    projectsNow.forEach { appendLine("- ${it.title}: ${it.description}") }
                    appendLine("SAVED PERSONAL CONTEXT:")
                    contextNow.forEach { appendLine("- [${it.category}; ${it.permanence}] ${it.content}") }
                    appendLine("COMMITMENTS:")
                    commitmentsNow.forEach { appendLine("- ${it.title}; starts ${it.startsAt}; ends ${it.endsAt}; ${it.recurrence}; ${it.notes}") }
                }.take(10000)
            }
            val history = withContext(Dispatchers.IO) { dao.recentMessages().asReversed() }
            val apiMessages = history.mapNotNull { message ->
                val role = when (message.role) { "USER" -> "user"; "ASSISTANT" -> "assistant"; else -> null }
                role?.let { it to message.content }
            }.takeLast(20)
            val reply = withContext(Dispatchers.IO) {
                AurenGatewayClient.send(secureStore.endpoint(), token, apiMessages, contextText)
            }
            dao.addMessage(MessageEntity(role = "ASSISTANT", content = reply))
            _aiStatus.value = "AUREN replied. Your conversation is saved on this device."
        } catch (error: Exception) {
            _aiStatus.value = "AUREN couldn't reply: ${error.message ?: "Unknown connection error"}"
        } finally {
            _sending.value = false
        }
    }
}
